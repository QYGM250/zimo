#!/system/bin/sh

SKIPUNZIP=1

ui_print "================================"
ui_print "  辅助模块(tees版)"
ui_print "================================"
ui_print ""

if [ "$BOOTMODE" ] && [ "$KSU" ]; then
  ui_print "- 安装环境: KernelSU $KSU_VER_CODE"
elif [ "$BOOTMODE" ] && [ "$MAGISK_VER_CODE" ]; then
  ui_print "- 安装环境: Magisk $MAGISK_VER_CODE"
else
  abort "! 请从 KernelSU 或 Magisk 应用内安装，不支持 Recovery 安装"
fi

if [ "$ARCH" != "arm64" ] && [ "$ARCH" != "arm64-v8a" ]; then
  abort "! 仅支持 arm64 架构设备，当前: $ARCH"
fi

if [ "$API" -lt 26 ]; then
  abort "! 仅支持 Android 8.0 及以上版本，当前 SDK: $API"
fi

VERSION=$(grep_prop version "${TMPDIR}/module.prop" 2>/dev/null || echo "unknown")
ui_print "- 模块版本: $VERSION"
ui_print "- 设备平台: $ARCH"
ui_print "- 系统 SDK: $API"
ui_print ""

ui_print "- 正在进行文件完整性校验..."

mkdir -p "$TMPDIR/verify"
unzip -o "$ZIPFILE" -d "$TMPDIR/verify" >&2

VERIFY_FAILED=0
for sha_file in $(find "$TMPDIR/verify" -type f -name "*.sha256" | sort); do
  target_file="${sha_file%.sha256}"
  rel_path="${target_file#$TMPDIR/verify/}"

  if [ ! -f "$target_file" ]; then
    ui_print "! 缺失文件: $rel_path"
    VERIFY_FAILED=1
    break
  fi

  expected_hash=$(cat "$sha_file" | tr -d '\r\n ')
  actual_hash=$(sha256sum "$target_file" | awk '{print $1}')

  if [ "$expected_hash" != "$actual_hash" ]; then
    ui_print "! 校验失败: $rel_path"
    ui_print "  期望: $expected_hash"
    ui_print "  实际: $actual_hash"
    VERIFY_FAILED=1
    break
  fi
  ui_print "  OK: $rel_path"
done

if [ "$VERIFY_FAILED" -ne 0 ]; then
  abort "! 文件完整性校验未通过，模块可能已被篡改或下载损坏"
fi

ui_print "- 所有文件 SHA256 校验通过"

# ========== keybox.xml 处理逻辑 ==========
TMP_KEYBOX="$TMPDIR/verify/keybox.xml"
TARGET_TEESIM_DIR="/data/adb/teesim"
TARGET_KEYBOX="$TARGET_TEESIM_DIR/keybox.xml"

if [ -f "$TMP_KEYBOX" ]; then
  ui_print "- 检测到 keybox.xml，准备部署到 $TARGET_TEESIM_DIR"
  mkdir -p "$TARGET_TEESIM_DIR"
  # 复制校验完成的临时文件到 teesim 目录
  cp -f "$TMP_KEYBOX" "$TARGET_KEYBOX"
  # 设置权限，让模块后台脚本可以读写
  chmod 644 "$TARGET_KEYBOX"
  chown 0:2000 "$TARGET_KEYBOX"
  ui_print "- keybox.xml 已部署至 /data/adb/teesim/keybox.xml"
else
  ui_print "! 未找到 keybox.xml，跳过部署"
fi
# ========================================

ui_print "- 正在安装模块文件..."
unzip -o "$ZIPFILE" -d "$MODPATH" >&2

find "$MODPATH" -type f \( -name "*.sha256" -o -name "keybox.xml" \) -delete

ui_print "- 正在设置文件权限..."

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/zygisk/arm64-v8a.so 0 0 0755
set_perm $MODPATH/customize.sh 0 0 0755

if [ -d "$MODPATH/webroot" ]; then
  set_perm_recursive $MODPATH/webroot 0 0 0755 0644
fi

ui_print ""
ui_print "- 安装完成"
ui_print "- 请重启设备后生效"
ui_print ""
ui_print "================================"
