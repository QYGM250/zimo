#!/sbin/sh
#####################
# Priv Protect Customization
#####################
SKIPUNZIP=1

unzip -j -o "${ZIPFILE}" '阿灵/*' -d $MODPATH/阿灵 >&2

unzip -j -o "${ZIPFILE}" 'service.sh' -d $MODPATH >&2
unzip -j -o "${ZIPFILE}" 'uninstall.sh' -d $MODPATH >&2
am start -a android.intent.action.VIEW -d tg://resolve?domain=ALING521 >/dev/null 2>&1

ui_print "- 生成 module.prop"
rm -rf $MODPATH/module.prop
touch $MODPATH/module.prop
echo "id=SELinux-LING" >$MODPATH/module.prop
echo "name=SELinux恢复(全自动🔄)" >>$MODPATH/module.prop
echo "version=TG频道@Whitelist520" >>$MODPATH/module.prop
echo "versionCode=20250723" >>$MODPATH/module.prop
echo "author=阿灵" >>$MODPATH/module.prop
echo "description=优点:无需手动恢复，无需重启设备\n使用GG修改器的同时,SELinux也不会处于宽容模式\n如果遇到需要SELinux必须宽容模式\n才可正常使用的软件,可临时停用模块" >>$MODPATH/module.prop

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/uninstall.sh 0 0 0755
set_perm $MODPATH/阿灵/SELinux 0 0 0777